import java.util.*;
class Inserction
  {
    public static void main(String a[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter Size:");
      int n=sc.nextInt();
      int arr[]=new int[n];
      for(int i=0;i<=n-1;i++)
        {
          arr[i]=sc.nextInt();
        }
      for(int i=1;i<=n-1;i++)
        {
      int temp=arr[i];
      int j=i-1;
      while(j>=0 && temp<arr[j])
        {
          arr[j+1]=arr[j];
          j=j-1;
        }
      arr[j+1]=temp;
    }
    for(int l=0;l<=n-1;l++)
  {
    System.out.println(arr[l]);
  }
  }
}