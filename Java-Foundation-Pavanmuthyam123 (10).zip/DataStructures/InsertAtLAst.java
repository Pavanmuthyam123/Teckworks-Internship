import java.util.*;
class LinkedList
  {
    class Node
  {
    int data;
    Node next;
    Node(int x)
    {
      data=x;
      next=null;
    }
  }
    Node head;
    public void insertEnd(int data)
    {
        Node newNode = new Node(data);
        if(head==null)
        {
            head = newNode;
            System.out.println(newNode.data + " inserted");
            return;
        }
            Node temp = head;
            while(temp.next!=null)
            temp = temp.next;
            temp.next = newNode;
            System.out.println(newNode.data + " inserted");
    } 
      public void display()
    {
      Node node=head;
      while(node!=null)
        {
          System.out.println(node.data+" ");
          node=node.next;
        }
      System.out.println();
    }
  } 
class InsertAtLast
  {
    public static void main(String r[])
    {
     LinkedList l=new LinkedList();
      l.insertEnd(1);
      l.insertEnd(2);
      l.insertEnd(3);
      l.insertEnd(4);
      l.insertEnd(100);
      l.display();
    }
  }