import java.util.*;
class LinkedList
  {
    class Node
  {
    int data;
    Node next;
    Node(int x)
    {
      data=x;
      next=null;
    }
  }
    Node head;
    public  void deleteStart()
    {  
        if(head==null)
        {    
         System.out.println("List is empty and not possible to delete");
            return;
        }
       System.out.println("deleted:"+head.data);
      head =head.next;
    }
    public Node insert(int data)
    {
      Node newNode=new Node(data);
      newNode.next=head;
      head=newNode;
      return head;
    }
  public void display()
    {
      Node node=head;
      while(node!=null)
        {
          System.out.println(node.data+" ");
          node=node.next;
        }
      System.out.println("\n");
    }
  } 
class DeleteAtHead
  {
    public static void main(String r[])
    {
     LinkedList l=new LinkedList();
      l.insert(1);
      l.insert(2);
      l.insert(3);
      l.insert(4);
      l.insert(100);
      l.display();
      l.deleteStart();
      l.display();
      l.deleteStart();
      l.deleteStart();
      l.display();
    }
  }