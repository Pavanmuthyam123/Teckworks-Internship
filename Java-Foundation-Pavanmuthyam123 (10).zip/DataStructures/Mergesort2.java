import java.util.*;
class Mergesort2
  {
    public static void main(String a[])
    {
      Scanner s=new Scanner(System.in);
      System.out.println("Enter size: ");
      int n=s.nextInt();
      int arr[]=new int[n];
      for(int i=0;i<=n;i++)
        {
          arr[i]=s.nextInt();
        }
      mergeSort(arr,n);
      for(int i=0;i<=n-1;i++)
        {
          System.out.println(arr[i]);
        }
      if(n<2) 
    {
        return;
    }
    int mid =n/2;
    int[] l=new int[mid];
    int[] r=new int[n-mid];
    for(int i=0;i<mid;i++)
     {
        l[i]=a[i];
     }
    for(int i=mid;i<=n;i++) 
    {
        r[i-mid]=a[i];
    }
    mergeSort(l,id);
    mergeSort(r,n-mid);
    merge(a,l,r,mid,n-mid);
    }
  }