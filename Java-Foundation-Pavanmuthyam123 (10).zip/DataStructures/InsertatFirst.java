import java.util.*;
class LinkedList
  {
    class Node
  {
    int data;
    Node next;
    Node(int x)
    {
      data=x;
      next=null;
    }
  }
    Node head;
    public  Node insertStart(int data)
    {
      Node newNode =new Node(data);
      newNode.next=head;
      head=newNode;
      System.out.println("inserted"+data);
      return head;
    }
    
  public void display()
    {
      Node node=head;
      while(node!=null)
        {
          System.out.println(node.data+" ");
          node=node.next;
        }
      System.out.println();
    }
  } 
class InsertAtFirst
  {
    public static void main(String r[])
    {
     LinkedList l=new LinkedList();
      l.insertStart(1);
      l.insertStart(2);
      l.insertStart(3);
      l.insertStart(4);
      l.display();
    }
  }