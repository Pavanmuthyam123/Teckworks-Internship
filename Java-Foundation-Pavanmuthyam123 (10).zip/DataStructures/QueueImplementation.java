import java.util.*;
class Queue 
{
  int front, rear;
  int capacity;
  int[] arr;
  Queue(int cap) 
  {
    capacity = cap;
    front = 0;
    rear = -1;
    arr = new int[capacity];
  }
  boolean isFull() 
  {
    if (rear == capacity - 1)
      System.out.println("overflow cannnot enqueue");
    return (rear == capacity - 1);
  }
  boolean isEmpty() 
  {
    if (front == -1)
      System.out.println("underflow , cannot dequeue");
    return (front == -1);
  }
  void enqueue(int item) 
  {
    if (isFull())
      return;
    if (front == -1)
      front = 0;
    rear++;
    arr[rear] = item;
    System.out.println(item + "enqueue to queue");
  }
  int dequeue()
  {
    if (isEmpty())
      return 0; 
    int item = arr[front];
    front++;
    if (front > rear)
      front = rear = -1;
    System.out.println(item + "dequeue from the Queue");
    return item;
  }
  int front() 
  {
    if (isEmpty())
      return 0; 
    return arr[front];
  }
  int rear() 
  {
    if (isEmpty())
      return 0;
      return arr[rear];
  }
}
class QueueImplementation
{
  public static void main(String[] r)
  {
    Queue queue = new Queue(5);
    queue.enqueue(10);
    queue.enqueue(20);
    queue.enqueue(40);
    queue.enqueue(90);
    queue.dequeue();
    queue.dequeue();
    System.out.println("Front :" + queue.front());
    System.out.println("Rear:" + queue.rear());
  }
}