import java.util.*;
class sumFirstandLast
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter Digits: ");
      int n=sc.nextInt();
      int f=0;
      int l=n%10;
      while(n!=0)
        {
          if(n/10==0)
        {
          f=n;
        }
          n=n/10;
        }
      int sum=f+l;
      System.out.println("Sum of Digits: "+sum);
    }
  }