import java.util.*;
class perfectNum
  {
    public static void main(String a[])
    {
      Scanner s=new Scanner(System.in);
      System.out.println("Enter the Number: ");
      int n=s.nextInt();
      int sum=0,i=1;
      for(int i=1;i<n;i++)
        {
          if(n%i==0)
          {
            sum=sum+i;
          }
        }
      if(sum=n)
      {
        System.out.println("It is a perfect Number: ");
      }
      else
      {
        System.out.println("It is not a perfect Number: ");
      }
    }
  }