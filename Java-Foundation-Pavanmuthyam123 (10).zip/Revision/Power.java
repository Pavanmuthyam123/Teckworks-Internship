import java.util.*;
class Power
  {
    public static void main(String args[])
    {
      Scanner s=new Scanner(System.in);
      System.out.println("Enter the base number: ");
      double b = s.nextDouble();
      System.out.println("Enter the Exponent Number: ");
      int e=s.nextInt();
      double res=1;
      for(int i=0;i<e;i++)
        {
          res=res*b;
        }
      System.out.println("The result is: "+res);
    }
  }