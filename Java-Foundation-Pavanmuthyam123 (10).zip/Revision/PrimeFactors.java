import java.util.*;
class PrimeFactors
  {
    public static void main(String args[])
    {
      Scanner s=new Scanner(System.in);
      System.out.println("Enter the Number: ");
      int a=s.nextInt();
       for(int i=2;i<a;i++) 
       {
         int c=0;
         if(a%i==0)
         {
           for(int j=2;j<=i;j++)
             {
               if(i%j==0)
               {
                 c++;
                 break;
               }
             }
         }
       }
      if(c==0)
      {
        System.out.println(i);
      }
    }
  }