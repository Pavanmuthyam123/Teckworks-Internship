import java.util.*;
class Dupicate
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter size of array");
      int size=sc.nextInt();
      int arr[]=new int[size];
      System.out.println("Enter array elements");
      for(int s=0;s<=(size-1);s++)
        arr[s]=sc.nextInt();
      int n=arr.length;
      for(int i=0;i<=(n-1);i++)
        {
          for(int j=i+1;j<=(n-1);j++)
            {
              if(a[i]==a[j])
              {
              System.out.println("DuplicateElement:"+a[j]);
                a[j]=a[n-1];
                n--;
                j--;
              }
            }
        }
      System.out.println("count of Duplicate elements:"+(size-n));
      System.out.println("Unique elements in array:");
      for(int f:arr)
        System.out.println(f);
    }
  }