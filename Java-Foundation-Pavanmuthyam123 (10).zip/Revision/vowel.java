import java.util.*;
class vowel
  {
    public static void main(String args[])
    {
      Scanner s=new Scanner(System.in);
      System.out.println("Enter a String ");
      String str=s.nextLine();
      fun(str);
    }
  public static void fun(String str)
    {
      char ch[]=str.tocharArray();
      for(int i=0;i<=str.length()-1;i++)
        {
          c[i]=1;
          for(int j=i+1;j<=str.length()-1;j++)
            {
              if(ch[i]==ch[j])
              {
                c[i]++;
                c[j]='0';
              }
            } 
        }
      for(int j=0;j<=c.length;j++)
        {
          if(c[j]==1 && c[j]!='0')
          {
            if(c[j]=='a'||c[j]=='e'||c[j]=='i'||c[j]=='o'||c[j]=='u')
          {
            System.out.println(c[j]);
          }
        }
       }
    }