import java.util.*;
class Strings
  {
    public static void main(String args[])
    {
      //String str="welcome";
      //find length of string
      //System.out.println(str.length());
      //String s="welcome";
      //using + operator
      //System.out.println(str+" "+s);
      //using concat operator
      //System.out.println(str.concat(s));

    String s1 = "welcome";
    String s2 = "welcome";
    String str1 = new String("welcome");
    String str2 = new String("welcome");
    // String comparision
    // 1. == operator always checks memory address of strings---> True /
    /*
     * System.out.println(s1 == s2);
     * System.out.println(str1 == str2);
     */
 
    // 3.equal()
    // always check the values of strings
    //System.out.println(s1.equals(s2));
    //System.out.println(str1.equals(str2));


      // character extraction methods
    // 1. charAt()---> single charcater from specific index
    // System.out.println(str2.charAt(8));
 
    // 2. getChars() ---> for getting more than one charater
    // which has to be stored in an array
    char[] c = new char[30];
 
    str2.getChars(2, 7, c, 6);
    System.out.println(c[0]);
    // 3. getBytes()---> will ascii value of each character
    /*
     * byte b[] = str2.getBytes();
     * for (byte i : b)
     * 
     * System.out.println(i);
     */
    // for converting string to character array
    // 4. toCharArray()
    char ch[] = str2.toCharArray();
    for (char f : ch)
      System.out.println(f);
    }
  }

    