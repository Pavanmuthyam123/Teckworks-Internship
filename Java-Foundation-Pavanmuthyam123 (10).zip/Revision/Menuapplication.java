import java.util.*;
class Menuapplication
  {
    public static void main(String k[])
    {
      Scanner s=new Scanner(System.in);
      System.out.println("Enter Number: ");
      int a=s.nextInt();
      System.out.println("Menu for Application: ");
      System.out.println("1.Check if Number is positive or Not: ");
      System.out.println("2.Check if Number is negative or Not: ");
      System.out.println("3.Check if Number is even or Not: ");
      System.out.println("4.Check if Number is odd or Not: ");
      System.out.println("5.Check if Number is prime or Not: ");
      System.out.println("Enter your choice: ");
      int choice=s.nextInt();
      switch(choice)
        {
          case 1:if(a>0)
          {
            System.out.println("It is positive: ");
          }
            else
          {
            System.out.println("It is not Positive: ");
          }
            break;
          case 2:if(a<0)
             {
            System.out.println("It is negative: ");
          }
            else
          {
            System.out.println("It is not negative: ");
          }
            break;
          case 3:if(a%2==0)
             {
            System.out.println("It is even: ");
          }
            else
          {
            System.out.println("It is not even: ");
          }
            break;
          case 4:if(a%2!=0)
          {
            System.out.println("It is odd: ");
          }
            else
          {
            System.out.println("It is not odd: ");
          }
            break;
          case 5:if(a>0)
          {
            int c=0;
            for(int m=1;m<=a;m++)
              {
                if(a%m==0)
                {
                  c++;
                }
              }
            if(c==2)
            {
              System.out.println("It is prime: ");
            }
            else
            {
              System.out.println("It is not prime");
            }
          }
          default:
            System.out.println("Choose coorect Number between 1 to 5: ");
    }
  }
  }