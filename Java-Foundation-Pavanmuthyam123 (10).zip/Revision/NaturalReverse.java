import java.util.*;
class NaturalReverse
  {
    public static void main(String a[])
    {
      Scanner sc=new Sacnner(System.in);
      System.out.println("Enter the num: ");
      int a=sc.nextInt();
      while(i>=a)
        {
          System.out.println(i);
          i--;
        }
    }  
  }