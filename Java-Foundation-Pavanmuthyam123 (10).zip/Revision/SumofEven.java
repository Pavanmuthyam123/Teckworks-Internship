import java.util.*;
class SumofEven
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter the number: ");
      int n=sc.nextInt();
      int num=1,sum=0;
      while(num<=n)
        {
          if(num%2==0)
          {
            sum=sum+num;
          }
          num++;
        }
      System.out.println("Even numbers"+n+"is: "+sum);
    }
  }