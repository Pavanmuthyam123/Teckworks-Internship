import java.util.*;
class CountandSay
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter numbers: ");
      int n=sc.nextInt();
      String str=" ";
      int count=1;
      for(int i=0;i<n;i++)
        {
          StringBuilder s=new StringBuilder();
          char ch=str.charAt(0);
          for(int j=1;j<str.length();j++)
            {
              if(str.charAt(j)==ch)
              {
                count++;
              }
            }
        }     
    }
  }