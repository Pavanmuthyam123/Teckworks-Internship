import java.util.*;
class FibonacciSeries
  {
    public static void main(String args[])
    {
      Scanner s=new Scanner(System.in);
      System.out.println("Enter no.of terms: ");
      int a=s.nextInt();
      int n1=0;
      int n2=1;
      System.out.println(a);
      System.out.println(n1+" "+n2);
      for(i=3;i<a;i++)
        {
          int res=n1+n2;
          System.out.println(res);
          n1=n2;
          n2=res;
        }
    }
  }