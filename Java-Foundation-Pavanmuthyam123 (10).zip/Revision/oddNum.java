import java.util.*;
class oddNum
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter the first number: ");
      int a=sc.nextInt();
      System.out.println("Enter the last number: ");
      int b=sc.nextInt();
      int num=a;
      while(num<=b)
        {
          if(num%2!=0)
          {
            System.out.println(num);
          }
          num++;
        }
    }
  }