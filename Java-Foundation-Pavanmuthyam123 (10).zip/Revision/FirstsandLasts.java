import java.util.*;
class FirstsandLasts
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter Digits: ");
      int n=sc.nextInt();
      int f=0;
      int l=n%10;
      while(n!=0)
        {
          f=n;
          n=n/10;
        }
      System.out.println("First Digit: "+f);
      System.out.println("Last Digit: "+l);
    }
  }