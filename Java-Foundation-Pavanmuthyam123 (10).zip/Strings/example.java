import java.util.*;

class simple {
  public static void main(String[] ar) {
    String str = new String();
    Scanner s = new Scanner(System.in);
    str = s.nextLine();
    // System.out.println(str);
    // System.out.println(str.concat("Pavan"));
    // System.out.println(str+"alladi");
    // System.out.println(str.toString());
    // String str1=new String(str);
    System.out.println(str.toString());
    // System.out.println(str1.toString());
    //  char p[] = new char[10];
    //str.getChars(3, 5, p, 3);
    //System.out.println(p);
   /*for(int i=0;i<p.length;i++)
    {
      System.out.println(p[i]);
    }*/
 byte b[]=str.getBytes();
  for(int i=0;i<b.length;i++)
    {
      System.out.println(b[i]);
    }
  char s1[]=str.toCharArray();
  for(int i=0;i<s1.length;i++)
    {
      System.out.println(s1[i]);
    }  
// System.out.println(str.charAt(13));
    // System.out.println(str.charAt(3));
    // System.out.println(str.split("1"));
    // String starr[]=str.split("1");
    /*
     * for(int i=0;i<starr.length;i++) { System.out.print(starr[i]+" "); }
     */

  }

}