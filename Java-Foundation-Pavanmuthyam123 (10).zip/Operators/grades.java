import java.util.Scanner;
class grades
  {
    public static void main(String args[])
    {
      Scanner s=new Scanner(System.in);
      System.out.println("enter sub Marks");
      int x1,x2,x3,x4;
      x1=s.nextInt();
      x2=s.nextInt();
      x3=s.nextInt();
      x4=s.nextInt();
      float per=(x1+x2+x3+x4)/4;
      System.out.println("Showing grade of student");
      if(per>=90)
      {
        System.out.println("grade 'a'");
      }
      else if(per>=80)
      {
        System.out.println("grade 'b'");
      }
      else if(per>=60)
      {
        System.out.println("grade 'c'");
      }
      else if(per>=50)
      {
        System.out.println("grade 'd'");
      }
      else
      {
        System.out.println("grade 'F'");
      }
      
      
    }
  }