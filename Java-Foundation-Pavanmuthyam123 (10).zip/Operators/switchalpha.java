import java.util.Scanner;
class switchalpha
  {
    public static void main(String args[])
    {
      char c;
      Scanner s=new Scanner(System.in);
      System.out.println("Enter the character");
      c=s.next().charAt(0);
      switch(c)
        {
          case 'a':
            System.out.println("a is vowel");
            break;
          case 'e':
            System.out.println("e is vowel");
            break;
          case 'i':
            System.out.println("i is vowel");
            break;
          case 'o':
            System.out.println("o is vowel");
            break;
          case 'u':
            System.out.println("u is vowel");
            break;
          default:
            System.out.println("not vowel");
            
          
          
        }
      
    }
  }