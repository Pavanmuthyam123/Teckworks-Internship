import java.util.Scanner;
public class elect
{
	public static void main(String args[])
	{
		Scanner s=new Scanner(System.in);
		System.out.println("enter units");
		int elect=s.nextInt();
	  double bill;
	  double charge;
		double res;
		if(elect<=50)
		{
			bill=elect*0.50;
		}
		else if(elect>=50 && elect<=150)
		{
			bill=elect*(0.75);
		}
		else if(elect>=150 && elect<=250)
		{
			bill=elect*1.20;
		}
		else
		{
			bill=elect*1.50;
		}
		charge=(20*bill)/100;
		res=charge+bill;
		System.out.println("total result "+res);
		
	}
}
			

	