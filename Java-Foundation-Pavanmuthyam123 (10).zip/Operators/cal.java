import java.util.Scanner;
class cal
  {
    public static void main(String args[])
    {
      int a,b;
      Scanner s= new Scanner(System.in);
      System.out.println("Enter a value: ");
      a=s.nextInt();
      System.out.println("Enter b value: ");
      b=s.nextInt();
      System.out.println("enter the operator: ");
      char ch=s.next().charAt(0);
      switch(ch)
        {
          case '+':
            System.out.println("addition val: "+(a+b));
            break;
          case '-':
             System.out.println("sub val "+(a-b));
            break;
          case '*':
             System.out.println("multiply val: "+(a*b));
            break;
          case '/':
             System.out.println("division val: "+(a/b));
            break;
          case '%':
             System.out.println("Modulo val: "+(a%b));
            break;
          default :
             System.out.println("Wrong choice:  ");
            break;
            
        }
    }
  }