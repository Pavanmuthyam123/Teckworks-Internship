import java.util.*;
class InvalidPinException extends Exception
  {
    public InvalidPinException(String message)
    {
      super(message);
    }
  }
class CustomAtm
{
    String correct_pin="0000";
    public void validpin(String pin) throws InvalidPinException
  {
  if(!pin.equals(correct_pin))
    {
     throw new InvalidPinException("Invalid pin Entered: ");
    }
  }
public static void main(String args[])
  {
    Scanner s=new Scanner(System.in);
    System.out.println("Enter your pin: ");
    String pin=s.nextLine();
    CustomAtm c=new CustomAtm();
  try
    {
      c.validpin(pin);
      System.out.println("pin validate Successful");
    }
  catch(InvalidPinException h)
    {
      System.out.println("pin is not valid");
    }
  }
}