import java.util.*;
class MenuApplication2
  {
    void Prime()
    {
      Scanner sc=new Scanner(System.in);        
		  System.out.print("Enter the Number :");
		  int num =sc.nextInt(); 
		  int i, count = 0;
		for(i=2;i<num;i++)
		{
			if(num%i==0)
			{
				count++;
				break;
			}
		}
		if(count==0)
			System.out.println("This is a Prime Number.");
		else
			System.out.println("This is not a Prime Number.");
	}
    void Palindrome()
    {
      Scanner sc= new Scanner(System.in);
		System.out.print("Enter The Digits :");
		int num =sc.nextInt();
		int rev = 0, rem, temp;
		temp = num;
		while (num != 0)
		{
			rem = num % 10;
			rev = rev * 10 + rem;
			num /= 10;
		}
		if (temp == rev)
			System.out.println ("It is Palindrome");
		else
			System.out.println (" is not Palindrome");
	}
    void Even()
    {
      Scanner sc=new Scanner(System.in);
		  System.out.print("Enter the Number  : ");
		  int l =sc.nextInt();
		  for(int s=1;s<=l;s++)
		 {
			if(l%2==0)
      {
				System.out.println("It is Even num ");
        break;
		  }
       else
      {
         System.out.println("It is Odd num ");
      }
	  }
    }
    void Odd()
    {
    Scanner sc=new Scanner(System.in);
		System.out.print("Enter the Number  : ");
		int l=sc.nextInt();
		for(int s=1;s<=l;s++)
		{
			if(l%2!=0)
        {
				  System.out.println("It is Even num ");
          break;
		    }
       else
        {
          System.out.println("It is Odd num ");
        }	
		}
	  }
        public static void main(String a[])
        {
          Scanner sc=new Scanner(System.in);
          char ch;
          int choice;
          MenuApplication2 obj=new MenuApplication2();
          System.out.println("1.Prime or not: ");
          System.out.println("2.Palindrome or not: ");
          System.out.println("3.Even or not: ");
          System.out.println("4.Odd or not: ");
      do
      {
        System.out.println("Enter Your choice: ");
        choice=sc.nextInt();
        switch(choice)
          {
            case 1:obj.Prime();
            break;
            case 2:obj.Palindrome();
            break;
            case 3:obj.Even();
            break;
            case 4:obj.Odd();
            break;
            default :System.out.println("Invalid Option");
		        break;
          } 
        System.out.println("Do tou want to continue one more Operation(y/n)");
		        ch=sc.next().charAt(0);
          }
        while(ch!='n');
      }
  }
