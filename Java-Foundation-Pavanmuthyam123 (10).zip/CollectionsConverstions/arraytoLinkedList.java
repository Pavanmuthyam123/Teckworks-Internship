
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
public class arraytoLinkedList 
{
	public static void main(String[] args)
  {
		String[] strArr = { "A", "B", "C", "D", "E" };
		// Convert array to list
		List<String> list = Arrays.asList(strArr);
		// Create a LinkedList and
		// pass List in LinkedList constructor
		LinkedList<String>linkedList= new LinkedList<>();
		System.out.println("LinkedList of array :""+ linkedList);
	}
}