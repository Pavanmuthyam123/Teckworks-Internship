interface empInterface
  {
    void insert();
    void delete();
    void search();
    void display();
  }