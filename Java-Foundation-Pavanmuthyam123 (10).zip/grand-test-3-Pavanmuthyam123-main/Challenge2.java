import java.util.*;
class Challenge2
  {
    public static void main(String args[])
    {
      System.out.println("Enter the Array size:");
      Scanner sc=new Scanner(System.in);
      int n=sc.nextInt();
      int arr[]=new int[n];
      System.out.println("Enter array elements: ");
      for(int i=0;i<size;i++)
        {
          arr[i]=sc.nextInt();
        }
      even_odd(arr,n);
      palindrome(arr,n);
      prime(arr,n);
      display();
    }
    public static void even_odd(int arr[],int n)
    {
      int c1=0,c2=0;
      for(int i=0;i<n;i++)
        {
          if(arr[i]%2==0)
          {
            c1=c1+1;
          }
          else
          {
            c2=c2+1;
          }
        }
      System.out.println("number of even numbers: "+c1);
      System.out.println("Number of odd numbers: "+c2);
    }
    public static void palindrome(int arr[],int n)
    {
      int sum=0,c3=0;
      for(int i=0;i<n;i++)
        {
          int temp=arr[i];
          while(temp!=0)
            {
              int r=temp%10;
              sum=sum*10+r;
              temp=temp/10;
            }
          if(sum==arr[i])
          {
            c3=c3+1;
          }
        }
      System.out.println("number of palindrome: "+c3);
    }
    public static void prime(int arr[],int n)
    {
      int c4=0;
      for(int i=0;i<n;i++)
        {
          int flag=0;
          for(int j=2;j<arr[i];j++)
            {
              if(arr[i]%j==0)
              {
                flag=1;
                break;
              }
            }
          if(flag==0)
          {
            c4=c4+1;
          }
        }
      System.out.println("Number of prime numbers: "+c4);
    }
  }