import java.util.*;
class idException extends Exception
  {
    public idException(String message)
    {
      super(message);
    }
  }
class Student
  {
    String id;
    String name;
    int rollno;
    long mobnum;
    int marks;
    String add;
    Scanner sc=new Scanner(System.in);
    void id()
    {
      System.out.println("Student id: ");
      try
        {
          id=sc.nextInt();
      if(id.length()!=5)
          {
             throw new idException("Student consists only 5 digits: ");
          }
        }
      catch(idException h)
        {
          System.out.println(h);
          id();
        }
    }
    String name()
    {
      System.out.println("Name: ");
      name=sc.nextLine();
      if((name.length()<2)||name.length()>30)
        {
          System.out.println("Name should be character: ");
          System.out.println("re enter it");
          name();
        }
      return name;
    }
    int rollno()
    {
      System.out.println("Roll No:");
      rollno=sc.nextInt();
      if(rollno<=0)
      {
        System.out.println("It should be positive:");
        System.out.println("re enter:");
        rollno();
      }
    String mobnum()
    {
      System.out.println("Enter Num: ");
      mobnum=sc.nextLine();
      if(mobnum.length()!=10||(mobnum.charAt(0)='9'||mobnum.charAt(0)='8'||mobnum.charAt(0)='7'||mobnum.charAt(0)='6'))
        System.out.println("Length should be 9,8,7,6");
      mobnum();
    }
      return mobnum;
    }
    int marks()
    {
      System.out.println("enter marks:");
      marks=sc.nextInt();
      if(marks<10)
      {
        System.out.println("re enter: ");
        marks();
      }
      return marks;
    }
    String add()
    {
      System.out.println("Enter address: ");
      add=sc.nextLine();
      if(add.length()<5||add.length()>100)
      {
        System.out.println("re enter:");
        add();
      }
      return add;
    } 
  }
class Challenge1
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter how many students do you want to add");
		int n=sc.nextInt();
		student arr[]=new student[n];
		String id;
		String name;
		int rollno;
		String mobnum;
		int marks;
		String add;
		int j=1;
		for(int i=0;i<n;i++) 
    {
			arr[i]=new student();
			System.out.println("enter data for student : "+j++);
			arr[i].id();
			arr[i].name();
			arr[i].rollno();
			arr[i].mobnum();
			[i].marks();
			arr[i].add();
		}
		for(int i=0;i<n;i++) 
    {
			System.out.println("Student id :"+arr[i].id);
			System.out.println("Name :"+arr[i].name);
			System.out.println("Roll NUmber :"+arr[i].rollno);
			System.out.println("Mobile :"+arr[i].mobnum);
			System.out.println("Marks :"+arr[i].marks);
			System.out.println("Address :"+arr[i].add);
		}
	}
}
    }
  }