import java.util.*;
class Publication
  {
    Scanner sc=new Scanner(System.in);
    Publication()
    {
      System.out.println("enter title: ");
      String title=sc.nextLine();
      System.out.println("Enter price: ");
      double price=sc.nextDouble();
      System.out.println("Enter num of copies sold: ");
      int copies=sc.nextInt();
      System.out.println("total sales: ");
      System.out.println(copies*price);
    }
  }
class Books extends Publication
  {
    Scanner sc=new Scanner(System.in);
    Books()
    {
      System.out.println("Enter autor name:");
      String author=sc.nextLine();
    }
  }
class Magazine extends Publication
  {
    Scanner s=new Scanner(System.in);
    Magazine()
    {
      System.out.println("Enter copies order :");
      int order=sc.nextInt();
    }
  }
public class Challenge3
  {
    public static void main(String args[])
    {
      Books b=new Books();
      Magazine ob=new Magazine();
    }
  }