import java.util.Scanner;
class Account
  {
    int accountnum;
    int balance;
    String holder;
    void get()
    {
      Scanner s=new Scanner(System.in);
      System.out.println("Enter account num: ");
      accountnum=s.nextInt();
      System.out.println("Enter balance: ");
      balance=s.nextInt();
      System.out.println("Enter Holder name: ");
      holder=s.nextLine();
    }
    void amountDeposite()
    {
      int amount;
      Scanner s=new Scanner(System.in);
      System.out.println("Enter deposite amount:");
      amount=s.nextInt();
      System.out.println("total amount: "+(amount+balance));
    }
    void withdraw()
    {
      int draw;
      Scanner s=new Scanner(System.in);
      System.out.println("Enter withdraw amount: ");
      draw=s.nextInt();
      System.out.println("total amount: "+(draw-balance));
    }
    void checkbalance()
    {
      Scanner s=new Scanner(System.in);
      System.out.println("total balance "+balance);
    }
  }
class Atm
  {
    public static void main(String args[])
    {
      Account p=new Account();
      p.get();
      p.amountDeposite();
      p.withdraw();
      p.checkbalance();
    }
  }