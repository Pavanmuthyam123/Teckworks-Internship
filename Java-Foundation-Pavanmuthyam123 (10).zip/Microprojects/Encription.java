import java.util.Scanner;
class Encription
  {
    public static void main(String args[])
    {
      String str=new String();
      Scanner s=new Scanner(System.in);
      System.out.println("Given String is: ");
      str=s.nextLine();
      System.out.println("read position num: ");
      int pos=s.nextInt();
      String str1=Encry(str,pos);
      System.out.println("before Encription: "+str);
      System.out.println("After Encription: "+str1);
      String str2=Decry(str1,pos);
      System.out.println("before Encription:"+str1);
      System.out.println("After Encription: "+str2);
    }
    public static String Encry(String str1,int p)
    {
      String res="";
      for(int i=0;i<str1.length();i++)
        {
          res=res+(char)(str1.charAt(i)+p%26);
        }
      return res;
    }
    public static String Decry(String str2,int p1)
    {
      String res1="";
      for(int i=0;i<str2.length();i++)
        {
          res1=res1+(char)(str2.charAt(i)-p1%26);
        }
      return res1;
    }
  }