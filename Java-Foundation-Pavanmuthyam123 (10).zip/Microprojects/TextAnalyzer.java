import java.util.Scanner;
class TextAnalyzer  
 {
    public static void main(String[] args) 
   {
      String s=new String();
      System.out.println(" Type Random sentence: ");
      Scanner sc=new Scanner(System.in);
      s=sc.nextLine();
      chars(s);
      words(s);
      lines(s);
   }
   static String chars(String m)
    {
     int count=0;
      for(int i=0; i<m.length; i++)
        {
          char ch=m.charAt(i);
          if(ch>='A' && ch<='Z' || ch>='a' && ch<='z')
          {
            count=count+1;
          } 
        }
      return(count);
    }
    static String words(String n)
    {
      int count=0;
      for(i=0; i<n.length; i++)
        {
          char ch=n.charAt(i);
          while((n=sc.readLine())!=nill)
            {
               String words[]=n.split(" ");
            }
          count=count+words.length; 
        }
       return(count);
    }
       static String lines(String k)
   {
       int count=0;
      for(j=0;j<k.length;j++)
        {
          char ch=k.charAt(j);
          if(s=k.charAt(j)==" ")
            {
            count=count+1;
            }
        }
    return(count);
   }
 }