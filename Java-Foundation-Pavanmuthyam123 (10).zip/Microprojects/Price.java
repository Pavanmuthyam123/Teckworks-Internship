import java.util.*;
class Price_Details
  {
    int price;
    String product;
    String quality;
    void getprice()
    {
      Scanner s=new Scanner(System.in);
      System.out.println("enter the product price:");
      price=s.nextInt();
    }
    void getquality()
    {
      Scanner s=new Scanner(System.in);
      System.out.println("enter the product quality:");
      quality=s.nextLine();
      System.out.println("Enter quality: "+quality); 
    }
    void getproduct()
    {
      Scanner s=new Scanner(System.in);
      System.out.println("enter the product:");
      product=s.nextLine();
      System.out.println("product name: "+product); 
    }
  }
class sales
  {
    public static void main(String args[])
    {
      Price_Details p=new Price_Details();
      p.getprice();
      p.getquality();
      p.getproduct();
    }
  }