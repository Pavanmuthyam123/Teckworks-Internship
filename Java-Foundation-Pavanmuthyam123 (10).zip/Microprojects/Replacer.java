import java.util.Scanner;
class Replacer 
 {
    public static void main(String[] args) 
   {
    Scanner s = new Scanner(System.in);
    System.out.print("Enter a string: ");
    String str1 = s.nextLine();
    System.out.print("Enter the word to replace: ");
    String str2 = s.nextLine();
    System.out.print("Enter the replacement word: ");
    String str3 = s.nextLine();
    String str;
    str=replaced(str1,str2,str3);
    System.out.println("Replaced string: " +str);
   } 
   public static String replaced(String s1,String s2,String s3)
   {
     String w[] = s1.split("");
     StringBuilder result = new StringBuilder();
     for (int i=0;i<w.length;i++)
       {
         String w1 = w[i];
         if(w1.equals(s2))
         {
           result.append(s3);
         }
         else
         {
           result.append(w1);
         }
         if (i<w.length-1)
         {
           result.append(" ");
         }
       }
      return result.toString();
   }
 }