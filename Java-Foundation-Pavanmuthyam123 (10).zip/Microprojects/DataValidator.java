import java.util.*;
class DataValidator
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("which data u want to check? ");
      System.out.println("1.username ");
      System.out.println("2.password ");
      System.out.println("3.mobile num ");
      int x=sc.nextInt();
      switch (x)
        {
          case 1:
            usernamecheck();
            break;
          case 2:
            passwordcheck(); 
            break;
          case 3:
          int r=mobilenumcheck();
             if(r==1)
      {
        System.out.println("It's valid mobilenumber");
      }
      else{
        System.out.println("It's invalid mobilenumber");
      }
      
            break;
        }
    }
    static void usernamecheck()
    {
      Scanner sc=new Scanner(System.in);
      String str=new String();
      System.out.println("enter username");
      str=sc.nextLine();
      if(str.length()>7)
      {
        system.out.println("invalid username");
      }
      else{
        int count=0;
        for(int l=0;l<str.length();l++)
          {
            if(str.charAt(l)>='A' && str.charAt(l)<='Z')
            {
              count++;
              break;
            }
          }
         for(int l=0;l<str.length();l++)
          {
            if(str.charAt(l)>='a' && str.charAt(l)<='z')
            {
              count++;
              break;
            }
          }
         for(int l=0;l<str.length();l++)
          {
            if(str.charAt(l)>='0' && str.charAt(l)<='9')
            {
              count++;
              break;
            }
          }
         for(int l=0;l<str.length();l++)
          {
            if(str.charAt(l)=='_'||str.charAt(l)=='@'||str.charAt(l)=='$')
            {
              count++;
              break;
            }
          }
      }
       if(count==4)
            {
              System.out.println("your Username is valid");
            }
            else{
              System.out.println("invalid usename");
            }
     
    }
    static void passwordcheck()
    {
       Scanner sc=new Scanner(System.in);
       String str=new String();
       System.out.println("enter password");
       str=sc.nextLine();
       if(str.length()>8)
        {
          system.out.println("invalid password");
        }
      else{
        int count=0;
        for(int l=0;l<str.length();l++)
          {
            if(str.charAt(l)>='A' && str.charAt(l)<='Z')
            {
              count++;
              break;
            }
          }
         for(int l=0;l<str.length();l++)
          {
            if(str.charAt(l)>='a' && str.charAt(l)<='z')
            {
              count++;
              break;
            }
          }
         for(int l=0;l<str.length();l++)
          {
            if(str.charAt(l)>='0' && str.charAt(l)<='9')
            {
              count++;
              break;
            }
          }
         for(int l=0;l<str.length();l++)
          {
            if(str.charAt(l)=='#'||str.charAt(l)=='@'||str.charAt(l)=='&')
            {
              count++;
              break;
            }
          }
      }
      if(count==4)
            {
              System.out.println("your password is valid");
            }
            else{
              System.out.println("invalid password");
            }
    }
    static int mobilenumcheck()
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter mobilenumber");
      String y=sc.nextLine();
      int count=0;
      for(int i=0;i<=y.length()-1;i++)
        {
          if(y.charAt(i)>='0' && y.charAt(i)<='9')
          {
            count=count+1;
          }
          else{
            System.out.println("invalid mobilenumber");
          }
        }
      if(count==10)
      {
        return 1;
      }
      else{
        return 0;
      }
    }
  }