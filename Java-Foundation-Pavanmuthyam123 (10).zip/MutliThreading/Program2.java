import java.util.*;
class program
  {
    public static void main(String a[])
    {
     int day=3;
      switch(day)
        {
        case 1:
          System.out.println("Monday: ");
          break;
        case 2:
          System.out.println("Tuesday: ");
         
        case 3:
          System.out.println("Thursday: ");
            break;
        default :
            System.out.println("Enter correct week num: ");       
        }
    }
  }