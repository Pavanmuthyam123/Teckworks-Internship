interface TouristerInterface
  {
    void TouristerDetails();
    void places();
    viod charges();
    void chooseVechicle();
    void viewAll();
  }