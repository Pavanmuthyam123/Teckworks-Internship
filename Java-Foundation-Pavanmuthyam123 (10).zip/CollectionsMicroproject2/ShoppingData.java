class ShoppingData
  {
    String name;
    double cost;
    char grade;
    public ShoppingData(String name,double cost,char grade)
    {
      name =name;
      cost =cost;
      grade =grade; 
      
    }
	public String getName() 
    {
		return name;
	}
	public double getCost() 
    
    {
		return cost;
	}
	public char getGrade() {
		return grade;
	}
}