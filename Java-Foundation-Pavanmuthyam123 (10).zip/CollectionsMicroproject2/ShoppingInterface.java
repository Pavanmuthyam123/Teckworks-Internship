interface ShoppingInterface
  {
    void add();
    void remove();
    void display();
    void total_cost();
  }