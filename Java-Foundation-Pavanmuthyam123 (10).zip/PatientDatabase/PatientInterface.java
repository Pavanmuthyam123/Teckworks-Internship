interface ManagementSystemInterface 
{
void addPatient();
void view();
void searchById();
void searchByName();
void searchByCity();
void searchByAge();
void recovery();
}