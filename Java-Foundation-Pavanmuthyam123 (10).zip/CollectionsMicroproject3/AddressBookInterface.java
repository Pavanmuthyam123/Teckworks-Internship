interface AddressBookInterface
    {
        void add();
        void edit();
        void delete();
        void search();
        void display();
    }