import java.util.Scanner;
class Sec2first
  {
    public static void main(String args[])
    {
      Scanner s=new Scanner(System.in);
      {
        String str1="[noun] was really[adj] today.we learned how to write";
        String str2[]=str1.split(" ");
        String s3,s4,s5;
        s3=s.nextLine();
        s4=s.nextLine();
        s5=s.nextLine();
        str2[0]=s3;
        str2[3]=s4;
        str2[10]=s5;
        for(int i=0;i<str2.length;i++)
          {
            System.out.println(str2[i]+" ");
          }
      }
    }
  }