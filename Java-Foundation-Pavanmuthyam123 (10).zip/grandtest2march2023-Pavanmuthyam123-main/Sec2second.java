import java.util.Scanner;
class Sec2second
  {
    public static void main(String args[])
    {
      System.out.println("Enter String: ");
      Scanner s=new Scanner(System.in);
      String str=s.next();
      second(str);
    }
    public static void second(String str)
    {
      String m="";
      String n="";
      for(int i=0;i<str.length()-1;i++)
        {
          if(i%2==0)
          {
            m=m+str.charAt(i);
          }
          else
          {
            n=n+str.charAt(i);
          }
        }
      System.out.println(m+n);
    }
  }