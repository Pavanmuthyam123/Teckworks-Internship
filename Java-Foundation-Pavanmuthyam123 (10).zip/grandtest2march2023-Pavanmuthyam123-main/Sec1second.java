import java.util.Scanner;
class Sec1second
  {
    public static void main(String args[])
    {
      System.out.println("Enter elements size: ");
      Scanner s=new Scanner(System.in);
      int n=s.nextInt();
      System.out.println("Enter num of elements to shift: ");
      int m=s.nextInt();
      int arr[]=new int[n];
      int temp[]=new int[m];
      System.out.println("enter array elements: ");
      for(int i=0;i<n;i++)
        {
          arr[i]=s.nextInt();
        }
      second(n,m,arr,temp); 
    }
    public static void second(int n,int m,int a[],int t[])
    {
      
      for(int i=0;i<m;i++)
        {
          t[i]=a[i];
        }
      for(int i=m;i<n;i++)
        {
          a[i-m]=a[i];
        }
      for(int i=0;i<m;i++)
        {
          a[i+n-m]=t[i];
        }
    System.out.println("array after shifting: ");
    for(int i=0;i<a.length;i++)
  {
    System.out.println(a[i]);
  }
}
  }