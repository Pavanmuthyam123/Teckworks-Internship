import java.util.Scanner;
class Sec1first
  {
    public static void main(String args[])
    {
      System.out.println("Enter amount to Withdraw: ");
      Scanner s=new Scanner(System.in);
      int amount=s.nextInt();
      sohie(amount);
    }
      public static void sohie(int amount)
        {
          int notes=0;
          while(amount>0)
              {
                if(amount>=500)
                   {
                     notes=notes+((int)amount/500);
                     amount=amount%500;
                   }
                else if(amount>=200)
                   {
                     notes=notes+((int)amount/200);
                     amount=amount%200;
                   }
                else
                   {
                     notes=notes+((int)amount/500);
                     amount=amount%100;
                   }
              }
           System.out.println("num of notes: "+notes);
      }
  }