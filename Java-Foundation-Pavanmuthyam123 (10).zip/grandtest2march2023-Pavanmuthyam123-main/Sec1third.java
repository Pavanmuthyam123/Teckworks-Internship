import java.util.Scanner;
class Sec1third
  {
    public static void main(String args[])
    {
      System.out.println("Enter no.of elements: ");
      Scanner s=new Scanner(System.in);
      int n=s.nextInt();
      int arr[]=new int[n];
      System.out.println("Enter target val: ");
      int target=s.nextInt();
      System.out.println("Enter array elements: ");
      for(int i=0;i<n;i++)
        {
          arr[i]=s.nextInt();
        }
            three(n,arr,target);
    }
    public static void three(int n,int a[],int tar)
    {
      System.out.println("include target sum: ");
      for(int i=0;i<n-1;i++)
        {
          for(int j=i+1;j<n;j++)
            {
              if(a[i]+a[j]==tar)
                System.out.println(i+" "+j);
            }
        }
    }
    
}