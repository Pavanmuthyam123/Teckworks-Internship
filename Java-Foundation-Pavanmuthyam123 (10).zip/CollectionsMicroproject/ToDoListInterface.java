interface ToDoListInterface
  {
    void add();
    void edit();
    void delete();
    void displayIncompleteTasks();
  }