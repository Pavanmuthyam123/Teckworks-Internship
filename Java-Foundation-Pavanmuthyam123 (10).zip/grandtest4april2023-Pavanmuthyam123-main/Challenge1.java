/*As a manager of a book shop, you are responsible for managing all the operations related to books in the shop. You have a system that stores all the book details(book_id, title, author, price) in an ArrayList of Book objects. 

Your task is to create a Java program that helps you manage the book shop efficiently.  

Create a console-based menu-driven program that allows the user to perform the following operations: 

1. Add books 

2. Calculate total price of all books 

3. Remove a book by book_id 

4. Update book price by book_id 

5. Search books by author 

6. Quit the program 

If no books are found for the given author name, the method should throw a custom exception called BookNotFoundException with an appropriate error message. 

Each menu option should call the corresponding method and display the results or appropriate error messages.*/
import java.util.*;
class Challange1
  {
    int book_id;
    String title;
    String author;
    double price;
    public Challange1(int book_id,String title,String author,double price)
    {
      this.book_id=book_id;
      this.title=title;
      this.author=author;
      this.price=price;
    }
    public book addbooks()
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter book Id: ");
      int id=sc.nextInt();
      System.out.println("Enter Book Title: ");
      String title=sc.next();
      System.out.println("Enter Author Name: ");
      String author=sc.next();
      System.out.println("Enter the Price: ");
      double price=sc.nextDouble();
      return new book(id,title,author,price);
    }
    static double totalprice()
    {
      double total=0;
      for(book obj:books)
        {
          total=total+obj.price;
        }
      return total;
    }
    static void removeBook()
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter bookId: ");
      int id=sc.nextInt();
      boolean verify=false;
      book temp=null;
      for(book obj:books)
        {
          if(obj.book_id==id)
          {
            verify=true;
            temp=obj;
          }
        }
      if(verify==false)
      {
        System.out.println("Book is not found: ");
      }
      else{
        System.out.println("Book is found: ");
        books.remove(temp);
      }
    }
    static void updateprice()
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter book Id: ");
      int id=sc.nextInt();
      System.out.println("Enter updated price: ");
      double price=sc.nextDouble();
      for(book obj:books)
        {
          if(obj.book_id==id)
          {
            obj.price=price;
          }
        }
    }
    static void SerachBooks()
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter author name: ");
      String author=sc.next();
      for(book obj:books)
        {
          if(obj.author==author)
          {
            toString(obj);
          }
        }
    }
    public static void main(String args[])
    {
      Scanner sc=new Scanner(Syetem.in);
      boolean flag=true;
      System.out.println("1.Enter 1 for adding: 2 for total price 3 for removing 4 for updating ");
      while(flag=true)
        {
          System.out.println("Enter choice: ");
          int choice=sc.nextInt();
          switch(flag)
            {
              case 1:addbook();
                break;
              case 2:totalprice();
                break;
              case 3:removeBook();
                break;
              case 4:updateBook();
                break;
              case 5:SerachBooks();
            }
        }
    }
  }
  