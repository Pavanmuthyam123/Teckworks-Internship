/*Challenge- 2: 

You have been tasked with creating a dictionary program in Java that stores words and their definitions using a hash map. The program should allow the user to add new words and definitions, view the definitions of existing words. Additionally, the program should handle exceptions when adding a word that already exists in the dictionary or trying to view the definition of a non-existent word.  

Create a console-based menu-driven program that allows the user to perform the following operations: 

1. Add Word and its definition 

2. View Definition 

3. Number of Words 

4. Search Words 

5. Exit 

Depending on the user's choice, prompt the user for the necessary inputs and call the appropriate methods to perform the required action */
import java.util.*;
class Challenge2
  {
    HashMap<String,String>dic=new HashMap<>();
    static void add()
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter word");
      String w=sc.next();
      String def=sc.next();
      dic.put(w,def);
    }
    static void nowords()
    {
      System.out.println(dic.size());
    }
    static void search()
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter word: ");
      String w=sc.next();
      boolean b=false;
      for(String s:dic.keyset())
        {
          if(s==w)
          {
            b=true;
            System.out.println("word is there:");
          }
        }
      if(b==false)
      {
        System.out.println("Not there: ");
      }
    }
    static void view()
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter your word: ");
      String w=sc.next();
      for(String s:dic.keySet())
        {
          System.out.println(" "+dic.get(w));
        }
    }
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      boolean flag=true;v
      System.out.println("1.Enter 1 for adding: 2 for total price 3 for removing 4 for updating ");
      while(flag=true)
        {
          System.out.println("Enter choice: ");
          int choice=sc.nextInt();
          switch(flag)
            {
              case 1:add();
                break;
              case 2:nowords();
                break;
              case 3:search();
                break;
              case 4:view();
                break;
            }
        }
    }
  }
